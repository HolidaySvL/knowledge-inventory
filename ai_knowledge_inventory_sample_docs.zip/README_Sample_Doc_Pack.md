# AI Knowledge Inventory MVP - Sample Manufacturing Document Pack

This synthetic document pack is designed for testing an AI Knowledge Inventory MVP. It simulates a traditional manufacturing / operations company with scattered SOPs, logs, checklists, training materials, and meeting notes.

The documents intentionally include realistic enterprise knowledge issues such as:

- unclear document owner
- missing or outdated version information
- vague business rules
- incomplete records
- cross-document dependencies
- ambiguous approval rules
- repeated operational issues
- content that should be treated as reference only, not source of truth
- high-risk documents requiring human review before entering a knowledge base

## Included Word Documents

1. `Supplier_Onboarding_SOP.docx`  
   Supplier onboarding process with missing owner/version and ambiguous quality approval.

2. `Purchase_Approval_Process.docx`  
   Purchase approval workflow with missing finance threshold and vague urgent-purchase exception rule.

3. `Customer_Complaint_Handling.docx`  
   Customer complaint procedure with unclear response SLA and escalation criteria.

4. `New_Employee_Training_Guide.docx`  
   Onboarding guide with outdated ERP screenshots, missing SOP list, and contact-update risk.

5. `Safety_Operation_Manual.docx`  
   Safety manual with high-risk content, TBD emergency contacts, and mandatory-vs-recommended wording.

6. `Monthly_Operations_Meeting_Notes.docx`  
   Cross-functional meeting notes with action items, pending decisions, and possible SOP update triggers.

## Included Excel Workbooks

1. `Equipment_Maintenance_Record.xlsx`  
   Maintenance log with inconsistent equipment IDs, missing technician, and recurring machine issue.

2. `Quality_Inspection_Checklist.xlsx`  
   Quality inspection checklist with vague acceptance criteria and recurring packaging defect.

3. `Production_Abnormal_Issue_Log.xlsx`  
   Production issue log with missing root causes and action items that should trigger SOP updates.

4. `Vendor_Evaluation_Form.xlsx`  
   Vendor evaluation form with undefined scoring criteria, unknown owner, and draft version status.

## Suggested MVP Test Outputs

A successful AI Knowledge Inventory MVP should be able to generate:

- `knowledge_inventory.xlsx`
- `process_map.md`
- `document_risk_report.md`
- `knowledge_gap_list.md`
- priority list of documents suitable for deep knowledge preparation

## Suggested AI Classification Expectations

The AI should classify documents across departments such as:

- Procurement
- Quality
- Production
- Maintenance
- EHS
- HR / Operations
- Sales / Customer Service

The AI should identify business processes such as:

- Supplier onboarding
- Purchase approval
- Customer complaint handling
- Equipment maintenance
- Quality inspection
- Production abnormal issue handling
- Vendor evaluation
- Employee onboarding
- Safety operation

## Important Note

All files are synthetic and created for MVP testing. They do not contain real company data.
